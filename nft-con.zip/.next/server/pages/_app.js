/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! swiper/css */ \"./node_modules/swiper/swiper.min.css\");\n/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! swiper/css/navigation */ \"./node_modules/swiper/modules/navigation/navigation.min.css\");\n/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(swiper_css_navigation__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! swiper/css/pagination */ \"./node_modules/swiper/modules/pagination/pagination.min.css\");\n/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(swiper_css_pagination__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var swiper_css_scrollbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swiper/css/scrollbar */ \"./node_modules/swiper/modules/scrollbar/scrollbar.min.css\");\n/* harmony import */ var swiper_css_scrollbar__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_scrollbar__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _styles_App_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../styles/App.css */ \"./styles/App.css\");\n/* harmony import */ var _styles_App_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_App_css__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var _styles_Layout_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../styles/Layout.css */ \"./styles/Layout.css\");\n/* harmony import */ var _styles_Layout_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_Layout_css__WEBPACK_IMPORTED_MODULE_6__);\n/* harmony import */ var _styles_font_icofont_min_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../styles/font/icofont.min.css */ \"./styles/font/icofont.min.css\");\n/* harmony import */ var _styles_font_icofont_min_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_styles_font_icofont_min_css__WEBPACK_IMPORTED_MODULE_7__);\n/* harmony import */ var _styles_section_global_style_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../styles/section/_global-style.scss */ \"./styles/section/_global-style.scss\");\n/* harmony import */ var _styles_section_global_style_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_styles_section_global_style_scss__WEBPACK_IMPORTED_MODULE_8__);\n/* harmony import */ var _styles_pages_PriceRangeSlider_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../styles/pages/PriceRangeSlider.css */ \"./styles/pages/PriceRangeSlider.css\");\n/* harmony import */ var _styles_pages_PriceRangeSlider_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_styles_pages_PriceRangeSlider_css__WEBPACK_IMPORTED_MODULE_9__);\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! next/head */ \"next/head\");\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_10__);\n/* harmony import */ var _inner_Social__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./inner/Social */ \"./pages/inner/Social.js\");\n/* harmony import */ var aos__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! aos */ \"aos\");\n/* harmony import */ var aos__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(aos__WEBPACK_IMPORTED_MODULE_12__);\n/* harmony import */ var aos_dist_aos_css__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! aos/dist/aos.css */ \"./node_modules/aos/dist/aos.css\");\n/* harmony import */ var aos_dist_aos_css__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(aos_dist_aos_css__WEBPACK_IMPORTED_MODULE_13__);\n/* harmony import */ var _styles_section_defi_css__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../styles/section/defi.css */ \"./styles/section/defi.css\");\n/* harmony import */ var _styles_section_defi_css__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_styles_section_defi_css__WEBPACK_IMPORTED_MODULE_14__);\n/* harmony import */ var _styles_section_marketing_css__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../styles/section/marketing.css */ \"./styles/section/marketing.css\");\n/* harmony import */ var _styles_section_marketing_css__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_styles_section_marketing_css__WEBPACK_IMPORTED_MODULE_15__);\n/* harmony import */ var _styles_section_metaverse_css__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../styles/section/metaverse.css */ \"./styles/section/metaverse.css\");\n/* harmony import */ var _styles_section_metaverse_css__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_styles_section_metaverse_css__WEBPACK_IMPORTED_MODULE_16__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_17__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_18__);\n/* harmony import */ var react_gtm_module__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! react-gtm-module */ \"react-gtm-module\");\n/* harmony import */ var react_gtm_module__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(react_gtm_module__WEBPACK_IMPORTED_MODULE_19__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_20__);\nvar _jsxFileName = \"D:\\\\monoj\\\\main-project\\\\nft-constructor (1)\\\\pages\\\\_app.js\";\n\nfunction ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }\n\nfunction _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }\n\nfunction _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nfunction MyApp({\n  Component,\n  pageProps\n}) {\n  (0,react__WEBPACK_IMPORTED_MODULE_17__.useEffect)(() => {\n    aos__WEBPACK_IMPORTED_MODULE_12___default().init({\n      easing: \"ease-out-cubic\",\n      once: true,\n      offset: 50\n    });\n  }, []);\n  const Layout = Component.layout || react__WEBPACK_IMPORTED_MODULE_17__.Fragment;\n  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_18__.useRouter)();\n  (0,react__WEBPACK_IMPORTED_MODULE_17__.useEffect)(() => {\n    react_gtm_module__WEBPACK_IMPORTED_MODULE_19___default().initialize({\n      gtmId: \"G-WXNBYYH45D\"\n    });\n  }, []);\n  (0,react__WEBPACK_IMPORTED_MODULE_17__.useEffect)(() => {\n    Promise.resolve(/*! import() */).then(__webpack_require__.t.bind(__webpack_require__, /*! react-facebook-pixel */ \"react-facebook-pixel\", 23)).then(x => x.default).then(ReactPixel => {\n      ReactPixel.init(\"776091353545037\"); // facebookPixelIds\n\n      ReactPixel.pageView();\n      router.events.on(\"routeChangeComplete\", () => {\n        ReactPixel.pageView();\n      });\n    });\n  }, [router.events]);\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_20__.Fragment, {\n    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxDEV)(Layout, {\n      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxDEV)(Component, _objectSpread({}, pageProps), void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 50,\n        columnNumber: 9\n      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_20__.jsxDEV)(_inner_Social__WEBPACK_IMPORTED_MODULE_11__[\"default\"], {}, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 51,\n        columnNumber: 9\n      }, this)]\n    }, void 0, true, {\n      fileName: _jsxFileName,\n      lineNumber: 49,\n      columnNumber: 7\n    }, this)\n  }, void 0, false);\n}\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7OztBQUNBLFNBQVNPLEtBQVQsQ0FBZTtBQUFFQyxFQUFBQSxTQUFGO0FBQWFDLEVBQUFBO0FBQWIsQ0FBZixFQUF5QztBQUN2Q0wsRUFBQUEsaURBQVMsQ0FBQyxNQUFNO0FBQ2RGLElBQUFBLGdEQUFBLENBQVM7QUFDUFMsTUFBQUEsTUFBTSxFQUFFLGdCQUREO0FBRVBDLE1BQUFBLElBQUksRUFBRSxJQUZDO0FBR1BDLE1BQUFBLE1BQU0sRUFBRTtBQUhELEtBQVQ7QUFLRCxHQU5RLEVBTU4sRUFOTSxDQUFUO0FBT0EsUUFBTUMsTUFBTSxHQUFHTixTQUFTLENBQUNPLE1BQVYsSUFBb0JaLDRDQUFuQztBQUNBLFFBQU1hLE1BQU0sR0FBR1gsdURBQVMsRUFBeEI7QUFDQUQsRUFBQUEsaURBQVMsQ0FBQyxNQUFNO0FBQ2RFLElBQUFBLG1FQUFBLENBQXNCO0FBQUVZLE1BQUFBLEtBQUssRUFBRTtBQUFULEtBQXRCO0FBQ0QsR0FGUSxFQUVOLEVBRk0sQ0FBVDtBQUdBZCxFQUFBQSxpREFBUyxDQUFDLE1BQU07QUFDZCxtSkFDR2UsSUFESCxDQUNTQyxDQUFELElBQU9BLENBQUMsQ0FBQ0MsT0FEakIsRUFFR0YsSUFGSCxDQUVTRyxVQUFELElBQWdCO0FBQ3BCQSxNQUFBQSxVQUFVLENBQUNaLElBQVgsQ0FBZ0IsaUJBQWhCLEVBRG9CLENBQ2dCOztBQUNwQ1ksTUFBQUEsVUFBVSxDQUFDQyxRQUFYO0FBRUFQLE1BQUFBLE1BQU0sQ0FBQ1EsTUFBUCxDQUFjQyxFQUFkLENBQWlCLHFCQUFqQixFQUF3QyxNQUFNO0FBQzVDSCxRQUFBQSxVQUFVLENBQUNDLFFBQVg7QUFDRCxPQUZEO0FBR0QsS0FUSDtBQVVELEdBWFEsRUFXTixDQUFDUCxNQUFNLENBQUNRLE1BQVIsQ0FYTSxDQUFUO0FBWUEsc0JBQ0U7QUFBQSwyQkFDRSwrREFBQyxNQUFEO0FBQUEsOEJBQ0UsK0RBQUMsU0FBRCxvQkFBZWYsU0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFFRSwrREFBQyxzREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREYsbUJBREY7QUFRRDs7QUFFRCxpRUFBZUYsS0FBZiIsInNvdXJjZXMiOlsid2VicGFjazovL215YXBwLy4vcGFnZXMvX2FwcC5qcz9lMGFkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcInN3aXBlci9jc3NcIjtcbmltcG9ydCBcInN3aXBlci9jc3MvbmF2aWdhdGlvblwiO1xuaW1wb3J0IFwic3dpcGVyL2Nzcy9wYWdpbmF0aW9uXCI7XG5pbXBvcnQgXCJzd2lwZXIvY3NzL3Njcm9sbGJhclwiO1xuaW1wb3J0IFwiLi4vc3R5bGVzL2dsb2JhbHMuY3NzXCI7XG5pbXBvcnQgXCIuLi9zdHlsZXMvQXBwLmNzc1wiO1xuaW1wb3J0IFwiLi4vc3R5bGVzL0xheW91dC5jc3NcIjtcbmltcG9ydCBcIi4uL3N0eWxlcy9mb250L2ljb2ZvbnQubWluLmNzc1wiO1xuaW1wb3J0IFwiLi4vc3R5bGVzL3NlY3Rpb24vX2dsb2JhbC1zdHlsZS5zY3NzXCI7XG5pbXBvcnQgXCIuLi9zdHlsZXMvcGFnZXMvUHJpY2VSYW5nZVNsaWRlci5jc3NcIjtcbmltcG9ydCBIZWFkIGZyb20gXCJuZXh0L2hlYWRcIjtcbmltcG9ydCBTb2NpYWwgZnJvbSBcIi4vaW5uZXIvU29jaWFsXCI7XG5pbXBvcnQgQW9zIGZyb20gXCJhb3NcIjtcbmltcG9ydCBcImFvcy9kaXN0L2Fvcy5jc3NcIjtcbmltcG9ydCBcIi4uL3N0eWxlcy9zZWN0aW9uL2RlZmkuY3NzXCI7XG5pbXBvcnQgXCIuLi9zdHlsZXMvc2VjdGlvbi9tYXJrZXRpbmcuY3NzXCI7XG5pbXBvcnQgXCIuLi9zdHlsZXMvc2VjdGlvbi9tZXRhdmVyc2UuY3NzXCI7XG5cbmltcG9ydCB7IEZyYWdtZW50LCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xuaW1wb3J0IFRhZ01hbmFnZXIgZnJvbSBcInJlYWN0LWd0bS1tb2R1bGVcIjtcbmZ1bmN0aW9uIE15QXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIEFvcy5pbml0KHtcbiAgICAgIGVhc2luZzogXCJlYXNlLW91dC1jdWJpY1wiLFxuICAgICAgb25jZTogdHJ1ZSxcbiAgICAgIG9mZnNldDogNTAsXG4gICAgfSk7XG4gIH0sIFtdKTtcbiAgY29uc3QgTGF5b3V0ID0gQ29tcG9uZW50LmxheW91dCB8fCBGcmFnbWVudDtcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgVGFnTWFuYWdlci5pbml0aWFsaXplKHsgZ3RtSWQ6IFwiRy1XWE5CWVlINDVEXCIgfSk7XG4gIH0sIFtdKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpbXBvcnQoXCJyZWFjdC1mYWNlYm9vay1waXhlbFwiKVxuICAgICAgLnRoZW4oKHgpID0+IHguZGVmYXVsdClcbiAgICAgIC50aGVuKChSZWFjdFBpeGVsKSA9PiB7XG4gICAgICAgIFJlYWN0UGl4ZWwuaW5pdChcIjc3NjA5MTM1MzU0NTAzN1wiKTsgLy8gZmFjZWJvb2tQaXhlbElkc1xuICAgICAgICBSZWFjdFBpeGVsLnBhZ2VWaWV3KCk7XG5cbiAgICAgICAgcm91dGVyLmV2ZW50cy5vbihcInJvdXRlQ2hhbmdlQ29tcGxldGVcIiwgKCkgPT4ge1xuICAgICAgICAgIFJlYWN0UGl4ZWwucGFnZVZpZXcoKTtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgfSwgW3JvdXRlci5ldmVudHNdKTtcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPExheW91dD5cbiAgICAgICAgPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPlxuICAgICAgICA8U29jaWFsIC8+XG4gICAgICA8L0xheW91dD5cbiAgICA8Lz5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgTXlBcHA7XG4iXSwibmFtZXMiOlsiSGVhZCIsIlNvY2lhbCIsIkFvcyIsIkZyYWdtZW50IiwidXNlRWZmZWN0IiwidXNlUm91dGVyIiwiVGFnTWFuYWdlciIsIk15QXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIiwiaW5pdCIsImVhc2luZyIsIm9uY2UiLCJvZmZzZXQiLCJMYXlvdXQiLCJsYXlvdXQiLCJyb3V0ZXIiLCJpbml0aWFsaXplIiwiZ3RtSWQiLCJ0aGVuIiwieCIsImRlZmF1bHQiLCJSZWFjdFBpeGVsIiwicGFnZVZpZXciLCJldmVudHMiLCJvbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./pages/inner/Social.js":
/*!*******************************!*\
  !*** ./pages/inner/Social.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);\nvar _jsxFileName = \"D:\\\\monoj\\\\main-project\\\\nft-constructor (1)\\\\pages\\\\inner\\\\Social.js\";\n\n\n\nfunction Social() {\n  const {\n    0: socialActive,\n    1: setSocialActive\n  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);\n\n  const _toggleSidebar = () => {\n    setSocialActive(!socialActive);\n  };\n\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"div\", {\n    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"div\", {\n      className: `${socialActive ? \"pulse-disable\" : \"\"} right-social`,\n      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"ul\", {\n        className: `${socialActive ? \"active\" : \"\"} social-ul-fixed`,\n        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"li\", {\n          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"a\", {\n            href: \"#\",\n            className: \"social-link\",\n            onClick: _toggleSidebar,\n            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"i\", {\n              className: `${socialActive ? \"icofont-close\" : \"icofont-live-support\"}`\n            }, void 0, false, {\n              fileName: _jsxFileName,\n              lineNumber: 16,\n              columnNumber: 15\n            }, this)\n          }, void 0, false, {\n            fileName: _jsxFileName,\n            lineNumber: 15,\n            columnNumber: 13\n          }, this)\n        }, void 0, false, {\n          fileName: _jsxFileName,\n          lineNumber: 14,\n          columnNumber: 11\n        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"li\", {\n          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"a\", {\n            href: \"https://wa.me/13025977087\",\n            className: \"social-link\",\n            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"i\", {\n              className: \"icofont-brand-whatsapp\"\n            }, void 0, false, {\n              fileName: _jsxFileName,\n              lineNumber: 25,\n              columnNumber: 15\n            }, this)\n          }, void 0, false, {\n            fileName: _jsxFileName,\n            lineNumber: 24,\n            columnNumber: 13\n          }, this)\n        }, void 0, false, {\n          fileName: _jsxFileName,\n          lineNumber: 23,\n          columnNumber: 11\n        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"li\", {\n          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"a\", {\n            href: \"https://web.facebook.com/nftconstructer?_rdc=1&_rdr\",\n            className: \"social-link\",\n            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"i\", {\n              className: \"icofont-facebook\"\n            }, void 0, false, {\n              fileName: _jsxFileName,\n              lineNumber: 33,\n              columnNumber: 15\n            }, this)\n          }, void 0, false, {\n            fileName: _jsxFileName,\n            lineNumber: 29,\n            columnNumber: 13\n          }, this)\n        }, void 0, false, {\n          fileName: _jsxFileName,\n          lineNumber: 28,\n          columnNumber: 11\n        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"li\", {\n          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"a\", {\n            href: \"https://t.me/nft_constructer\",\n            className: \"social-link\",\n            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"i\", {\n              className: \"icofont-telegram\"\n            }, void 0, false, {\n              fileName: _jsxFileName,\n              lineNumber: 38,\n              columnNumber: 15\n            }, this)\n          }, void 0, false, {\n            fileName: _jsxFileName,\n            lineNumber: 37,\n            columnNumber: 13\n          }, this)\n        }, void 0, false, {\n          fileName: _jsxFileName,\n          lineNumber: 36,\n          columnNumber: 11\n        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"li\", {\n          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"a\", {\n            href: \"mailto:support@nftconstructer.com\",\n            className: \"social-link\",\n            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"i\", {\n              className: \"icofont-email\"\n            }, void 0, false, {\n              fileName: _jsxFileName,\n              lineNumber: 43,\n              columnNumber: 15\n            }, this)\n          }, void 0, false, {\n            fileName: _jsxFileName,\n            lineNumber: 42,\n            columnNumber: 13\n          }, this)\n        }, void 0, false, {\n          fileName: _jsxFileName,\n          lineNumber: 41,\n          columnNumber: 11\n        }, this)]\n      }, void 0, true, {\n        fileName: _jsxFileName,\n        lineNumber: 13,\n        columnNumber: 9\n      }, this)\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 12,\n      columnNumber: 7\n    }, this)\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 11,\n    columnNumber: 5\n  }, this);\n}\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Social);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9pbm5lci9Tb2NpYWwuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7OztBQUVBLFNBQVNFLE1BQVQsR0FBa0I7QUFDaEIsUUFBTTtBQUFBLE9BQUNDLFlBQUQ7QUFBQSxPQUFlQztBQUFmLE1BQWtDSiwrQ0FBUSxDQUFDLEtBQUQsQ0FBaEQ7O0FBRUEsUUFBTUssY0FBYyxHQUFHLE1BQU07QUFDM0JELElBQUFBLGVBQWUsQ0FBQyxDQUFDRCxZQUFGLENBQWY7QUFDRCxHQUZEOztBQUlBLHNCQUNFO0FBQUEsMkJBQ0U7QUFBSyxlQUFTLEVBQUcsR0FBRUEsWUFBWSxHQUFHLGVBQUgsR0FBcUIsRUFBRyxlQUF2RDtBQUFBLDZCQUNFO0FBQUksaUJBQVMsRUFBRyxHQUFFQSxZQUFZLEdBQUcsUUFBSCxHQUFjLEVBQUcsa0JBQS9DO0FBQUEsZ0NBQ0U7QUFBQSxpQ0FDRTtBQUFHLGdCQUFJLEVBQUMsR0FBUjtBQUFZLHFCQUFTLEVBQUMsYUFBdEI7QUFBb0MsbUJBQU8sRUFBRUUsY0FBN0M7QUFBQSxtQ0FDRTtBQUNFLHVCQUFTLEVBQUcsR0FDVkYsWUFBWSxHQUFHLGVBQUgsR0FBcUIsc0JBQ2xDO0FBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBVUU7QUFBQSxpQ0FDRTtBQUFHLGdCQUFJLEVBQUMsMkJBQVI7QUFBb0MscUJBQVMsRUFBQyxhQUE5QztBQUFBLG1DQUNFO0FBQUcsdUJBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFWRixlQWVFO0FBQUEsaUNBQ0U7QUFDRSxnQkFBSSxFQUFDLHFEQURQO0FBRUUscUJBQVMsRUFBQyxhQUZaO0FBQUEsbUNBSUU7QUFBRyx1QkFBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWZGLGVBdUJFO0FBQUEsaUNBQ0U7QUFBRyxnQkFBSSxFQUFDLDhCQUFSO0FBQXVDLHFCQUFTLEVBQUMsYUFBakQ7QUFBQSxtQ0FDRTtBQUFHLHVCQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBdkJGLGVBNEJFO0FBQUEsaUNBQ0U7QUFBRyxnQkFBSSxFQUFDLG1DQUFSO0FBQTRDLHFCQUFTLEVBQUMsYUFBdEQ7QUFBQSxtQ0FDRTtBQUFHLHVCQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUF3Q0Q7O0FBRUQsaUVBQWVELE1BQWYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teWFwcC8uL3BhZ2VzL2lubmVyL1NvY2lhbC5qcz8wNzA3Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmZ1bmN0aW9uIFNvY2lhbCgpIHtcclxuICBjb25zdCBbc29jaWFsQWN0aXZlLCBzZXRTb2NpYWxBY3RpdmVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBfdG9nZ2xlU2lkZWJhciA9ICgpID0+IHtcclxuICAgIHNldFNvY2lhbEFjdGl2ZSghc29jaWFsQWN0aXZlKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9e2Ake3NvY2lhbEFjdGl2ZSA/IFwicHVsc2UtZGlzYWJsZVwiIDogXCJcIn0gcmlnaHQtc29jaWFsYH0+XHJcbiAgICAgICAgPHVsIGNsYXNzTmFtZT17YCR7c29jaWFsQWN0aXZlID8gXCJhY3RpdmVcIiA6IFwiXCJ9IHNvY2lhbC11bC1maXhlZGB9PlxyXG4gICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICA8YSBocmVmPScjJyBjbGFzc05hbWU9J3NvY2lhbC1saW5rJyBvbkNsaWNrPXtfdG9nZ2xlU2lkZWJhcn0+XHJcbiAgICAgICAgICAgICAgPGlcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7XHJcbiAgICAgICAgICAgICAgICAgIHNvY2lhbEFjdGl2ZSA/IFwiaWNvZm9udC1jbG9zZVwiIDogXCJpY29mb250LWxpdmUtc3VwcG9ydFwiXHJcbiAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICA+PC9pPlxyXG4gICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICA8YSBocmVmPSdodHRwczovL3dhLm1lLzEzMDI1OTc3MDg3JyBjbGFzc05hbWU9J3NvY2lhbC1saW5rJz5cclxuICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9J2ljb2ZvbnQtYnJhbmQtd2hhdHNhcHAnPjwvaT5cclxuICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgPC9saT5cclxuICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICBocmVmPSdodHRwczovL3dlYi5mYWNlYm9vay5jb20vbmZ0Y29uc3RydWN0ZXI/X3JkYz0xJl9yZHInXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPSdzb2NpYWwtbGluaydcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT0naWNvZm9udC1mYWNlYm9vayc+PC9pPlxyXG4gICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgPGxpPlxyXG4gICAgICAgICAgICA8YSBocmVmPSdodHRwczovL3QubWUvbmZ0X2NvbnN0cnVjdGVyJyBjbGFzc05hbWU9J3NvY2lhbC1saW5rJz5cclxuICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9J2ljb2ZvbnQtdGVsZWdyYW0nPjwvaT5cclxuICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgPC9saT5cclxuICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgPGEgaHJlZj0nbWFpbHRvOnN1cHBvcnRAbmZ0Y29uc3RydWN0ZXIuY29tJyBjbGFzc05hbWU9J3NvY2lhbC1saW5rJz5cclxuICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9J2ljb2ZvbnQtZW1haWwnPjwvaT5cclxuICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgPC9saT5cclxuICAgICAgICA8L3VsPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFNvY2lhbDtcclxuIl0sIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiU29jaWFsIiwic29jaWFsQWN0aXZlIiwic2V0U29jaWFsQWN0aXZlIiwiX3RvZ2dsZVNpZGViYXIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/inner/Social.js\n");

/***/ }),

/***/ "./node_modules/aos/dist/aos.css":
/*!***************************************!*\
  !*** ./node_modules/aos/dist/aos.css ***!
  \***************************************/
/***/ (() => {



/***/ }),

/***/ "./node_modules/swiper/modules/navigation/navigation.min.css":
/*!*******************************************************************!*\
  !*** ./node_modules/swiper/modules/navigation/navigation.min.css ***!
  \*******************************************************************/
/***/ (() => {



/***/ }),

/***/ "./node_modules/swiper/modules/pagination/pagination.min.css":
/*!*******************************************************************!*\
  !*** ./node_modules/swiper/modules/pagination/pagination.min.css ***!
  \*******************************************************************/
/***/ (() => {



/***/ }),

/***/ "./node_modules/swiper/modules/scrollbar/scrollbar.min.css":
/*!*****************************************************************!*\
  !*** ./node_modules/swiper/modules/scrollbar/scrollbar.min.css ***!
  \*****************************************************************/
/***/ (() => {



/***/ }),

/***/ "./node_modules/swiper/swiper.min.css":
/*!********************************************!*\
  !*** ./node_modules/swiper/swiper.min.css ***!
  \********************************************/
/***/ (() => {



/***/ }),

/***/ "./styles/App.css":
/*!************************!*\
  !*** ./styles/App.css ***!
  \************************/
/***/ (() => {



/***/ }),

/***/ "./styles/Layout.css":
/*!***************************!*\
  !*** ./styles/Layout.css ***!
  \***************************/
/***/ (() => {



/***/ }),

/***/ "./styles/font/icofont.min.css":
/*!*************************************!*\
  !*** ./styles/font/icofont.min.css ***!
  \*************************************/
/***/ (() => {



/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "./styles/pages/PriceRangeSlider.css":
/*!*******************************************!*\
  !*** ./styles/pages/PriceRangeSlider.css ***!
  \*******************************************/
/***/ (() => {



/***/ }),

/***/ "./styles/section/_global-style.scss":
/*!*******************************************!*\
  !*** ./styles/section/_global-style.scss ***!
  \*******************************************/
/***/ (() => {



/***/ }),

/***/ "./styles/section/defi.css":
/*!*********************************!*\
  !*** ./styles/section/defi.css ***!
  \*********************************/
/***/ (() => {



/***/ }),

/***/ "./styles/section/marketing.css":
/*!**************************************!*\
  !*** ./styles/section/marketing.css ***!
  \**************************************/
/***/ (() => {



/***/ }),

/***/ "./styles/section/metaverse.css":
/*!**************************************!*\
  !*** ./styles/section/metaverse.css ***!
  \**************************************/
/***/ (() => {



/***/ }),

/***/ "aos":
/*!**********************!*\
  !*** external "aos" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("aos");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-facebook-pixel":
/*!***************************************!*\
  !*** external "react-facebook-pixel" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-facebook-pixel");

/***/ }),

/***/ "react-gtm-module":
/*!***********************************!*\
  !*** external "react-gtm-module" ***!
  \***********************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-gtm-module");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.js"));
module.exports = __webpack_exports__;

})();